export function getTopDiagnosisId(state) {
  return state.sortedDDx?.[0]?.id || null;
}

export function getDiagnosisData(diagnoses, diagnosisId) {
  if (!diagnosisId) return null;
  return diagnoses[diagnosisId] || null;
}

export function getTopDiagnosisData(diagnoses, state) {
  const topId = getTopDiagnosisId(state);
  return getDiagnosisData(diagnoses, topId);
}