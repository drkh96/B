import {
  createInterviewState,
  answerQuestion
} from "./interview-engine.js";

import {
  getTopDiagnosisData
} from "./diagnosis-engine.js";

import diagnoses from "../database/diagnoses/index.js";

class InterviewController {
  constructor(module) {
    this.module = module;
    this.diagnoses = diagnoses;
    this.state = createInterviewState(module.ddx);

    this.flow = [
      ...module.history.initialFlow
    ];
  }

  answer(question, answer) {
    this.state = answerQuestion(
      this.state,
      question,
      answer,
      this.module.decision.logic
    );

    this.updateFlow();

    return this.state;
  }

  updateFlow() {
    this.state.nextSections.forEach(sectionId => {
      const section = this.module.history.conditionalSections[sectionId];

      if (!section) return;

      const alreadyExists = this.flow.some(item => item.id === sectionId);

      if (!alreadyExists) {
        this.flow.push({
          id: sectionId,
          title: section.title,
          questions: section.questions
        });
      }
    });
  }

  getFlow() {
    return this.flow;
  }

  getState() {
    return this.state;
  }

  getDDx() {
    return this.state.sortedDDx;
  }

  getReasoning() {
    return this.module.decision.reasoning(this.state.ddx);
  }

  getTopDiagnosis() {
    return getTopDiagnosisData(this.diagnoses, this.state);
  }

  getReport(patient = {}) {
    const topDiagnosis = this.getTopDiagnosis();

    return {
      caseScenario: this.module.report.caseScenario(patient, this.state),
      examination: topDiagnosis?.examination || this.module.report.examination(patient, this.state),
      investigations: topDiagnosis?.investigations || this.module.report.investigations(patient, this.state),
      management: topDiagnosis?.management || this.module.report.management(patient, this.state),
      complications: topDiagnosis?.complications || null
    };
  }

  reset() {
    this.state = createInterviewState(this.module.ddx);
    this.flow = [...this.module.history.initialFlow];
  }
}

export default InterviewController;