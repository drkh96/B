import * as diagnosisEngine from "./diagnosis-engine.js";
import interviewController from "./interview-controller.js";
import interviewEngine from "./interview-engine.js";
import scoring from "./scoring.js";

const engine = {
  diagnosisEngine,
  interviewController,
  interviewEngine,
  scoring
};

export default engine;