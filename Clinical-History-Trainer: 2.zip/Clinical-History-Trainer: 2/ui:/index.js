import app from "./app/index.js";

const ui = {
  app
};

export default ui;