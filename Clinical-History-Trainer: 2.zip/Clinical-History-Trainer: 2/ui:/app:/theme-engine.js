const THEME_KEY = "medaid-theme";

export const themes = {
  default: "theme-default",
  boy: "theme-boy",
  girl: "theme-girl",
  amoled: "theme-amoled",
  doctor: "theme-doctor"
};

export function applyTheme(themeName = "default") {
  const selectedTheme = themes[themeName] || themes.default;

  document.body.classList.forEach(className => {
    if (className.startsWith("theme-")) {
      document.body.classList.remove(className);
    }
  });

  document.body.classList.add(selectedTheme);
  localStorage.setItem(THEME_KEY, themeName);
}

export function loadSavedTheme() {
  const savedTheme = localStorage.getItem(THEME_KEY) || "default";
  applyTheme(savedTheme);
}

export function getCurrentTheme() {
  return localStorage.getItem(THEME_KEY) || "default";
}

export function registerTheme(themeName, themeClass) {
  themes[themeName] = themeClass;
}