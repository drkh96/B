import "./app.js";

const app = {};

export default app;