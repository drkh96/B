// ===============================
// MedAid Application
// ===============================

import {
  loadSavedTheme,
  applyTheme,
  getCurrentTheme
} from "./theme-engine.js";

import { renderHomePage } from "../pages/home/index.js";


// ===============================
// Initialize Application
// ===============================

function initializeApp() {
  loadSavedTheme();

  const root = document.getElementById("app");
  root.innerHTML = renderHomePage();

  console.log("MedAid Started");
  console.log("Current Theme:", getCurrentTheme());
}

// ===============================
// Global Functions
// ===============================

window.applyTheme = applyTheme;

// ===============================
// Start App
// ===============================

initializeApp();