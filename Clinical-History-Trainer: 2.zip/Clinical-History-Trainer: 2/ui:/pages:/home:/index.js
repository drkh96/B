export function renderHomePage() {
  return `
    <main class="home-page">
      <section class="hero-card">
        <div>
          <p class="eyebrow">Clinical History Trainer</p>
          <h1>MedAid</h1>
          <p class="subtitle">Smart history taking with live DDx and clinical reasoning.</p>
        </div>

        <div class="theme-buttons">
          <button onclick="applyTheme('boy')">Boy Mode 💙</button>
          <button onclick="applyTheme('girl')">Princess Mode 🌸✨</button>
        </div>
      </section>

      <section class="subject-grid">
        <button class="subject-card">Internal Medicine</button>
        <button class="subject-card">Surgery</button>
        <button class="subject-card">Pediatrics</button>
        <button class="subject-card">Obstetrics & Gynecology</button>
      </section>
    </main>
  `;
}