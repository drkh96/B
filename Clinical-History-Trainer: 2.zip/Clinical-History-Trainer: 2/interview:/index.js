const interview = {};

export default interview;