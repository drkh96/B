import internalMedicine from "./internal-medicine/index.js";

const systems = {
  internalMedicine
};

export default systems;