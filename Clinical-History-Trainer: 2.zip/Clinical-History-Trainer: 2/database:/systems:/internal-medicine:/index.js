const internalMedicineSystems = {
  id: "internal-medicine",

  name: {
    ar: "أنظمة الباطنية",
    en: "Internal Medicine Systems"
  },

  systems: {}
};

export default internalMedicineSystems;