import consultation from "./consultation/index.js";
import chiefComplaint from "./chief-complaint/index.js";
import reviewOfSystems from "./review-of-systems/index.js";
import pastMedicalHistory from "./past-medical-history/index.js";
import pastSurgicalHistory from "./past-surgical-history/index.js";
import drugHistory from "./drug-history/index.js";
import familyHistory from "./family-history/index.js";
import socialHistory from "./social-history/index.js";
import closing from "./closing/index.js";

const common = {
  consultation,
  chiefComplaint,
  reviewOfSystems,
  pastMedicalHistory,
  pastSurgicalHistory,
  drugHistory,
  familyHistory,
  socialHistory,
  closing
};

export default common;