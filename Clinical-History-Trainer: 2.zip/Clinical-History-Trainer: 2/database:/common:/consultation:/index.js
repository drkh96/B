import greeting from "./greeting.js";
import identity from "./identity.js";
import consent from "./consent.js";
import privacy from "./privacy.js";
import communication from "./communication.js";

const consultation = {
  greeting,
  identity,
  consent,
  privacy,
  communication
};

export default consultation;
