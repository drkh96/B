import closing from "./closing.js";

const closingSection = {
  closing
};

export default closingSection;