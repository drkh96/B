import arrhythmias from "./arrhythmias.js";
import heartFailure from "./heart-failure.js";
import cardiogenicShock from "./cardiogenic-shock.js";
import mechanical from "./mechanical.js";
import thromboembolism from "./thromboembolism.js";

const complications = {
  arrhythmias,
  heartFailure,
  cardiogenicShock,
  mechanical,
  thromboembolism
};

export default complications;