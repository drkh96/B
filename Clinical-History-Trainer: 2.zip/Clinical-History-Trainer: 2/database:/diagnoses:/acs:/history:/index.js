import clinicalFeatures from "./clinical-features.js";
import redFlags from "./red-flags.js";
import riskFactors from "./risk-factors.js";

const history = {
  clinicalFeatures,
  redFlags,
  riskFactors
};

export default history;