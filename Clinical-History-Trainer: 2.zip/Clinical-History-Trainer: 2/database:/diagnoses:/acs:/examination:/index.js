import general from "./general.js";
import cardiovascular from "./cardiovascular.js";
import respiratory from "./respiratory.js";

const examination = {
  general,
  cardiovascular,
  respiratory
};

export default examination;