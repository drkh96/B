import acs from "./acs/index.js";

const diagnoses = {
  "acute-coronary-syndrome": acs
};

export default diagnoses;