import internalMedicine from "./internal-medicine/index.js";

const symptoms = {
  internalMedicine
};

export default symptoms;