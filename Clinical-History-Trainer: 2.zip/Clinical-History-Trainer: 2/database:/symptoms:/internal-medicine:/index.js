import cvs from "./cvs/index.js";

const internalMedicine = {
  cvs
};

export default internalMedicine;