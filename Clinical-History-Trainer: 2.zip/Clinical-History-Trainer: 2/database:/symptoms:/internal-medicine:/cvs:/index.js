import chestPain from "./chest-pain/index.js";

const cvs = {
  chestPain
};

export default cvs;