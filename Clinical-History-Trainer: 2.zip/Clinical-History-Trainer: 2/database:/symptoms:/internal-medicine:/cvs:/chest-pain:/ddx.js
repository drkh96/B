const ddx = {
  "acute-coronary-syndrome": {
    score: 0,
    reasons: []
  },

  "myocardial-infarction": {
    score: 0,
    reasons: []
  },

  "unstable-angina": {
    score: 0,
    reasons: []
  },

  "stable-angina": {
    score: 0,
    reasons: []
  },

  "aortic-dissection": {
    score: 0,
    reasons: []
  },

  "pericarditis": {
    score: 0,
    reasons: []
  },

  "myocarditis": {
    score: 0,
    reasons: []
  },

  "mitral-valve-prolapse": {
    score: 0,
    reasons: []
  },

  "pulmonary-embolism": {
    score: 0,
    reasons: []
  },

  "pneumonia": {
    score: 0,
    reasons: []
  },

  "pneumothorax": {
    score: 0,
    reasons: []
  },

  "pleurisy": {
    score: 0,
    reasons: []
  },

  "gord": {
    score: 0,
    reasons: []
  },

  "costochondritis": {
    score: 0,
    reasons: []
  },

  "muscle-injury": {
    score: 0,
    reasons: []
  },

  "muscle-spasm": {
    score: 0,
    reasons: []
  },

  "rib-fracture": {
    score: 0,
    reasons: []
  },

  "herpes-zoster": {
    score: 0,
    reasons: []
  },

  "heart-failure": {
    score: 0,
    reasons: []
  },

  "atrial-fibrillation": {
    score: 0,
    reasons: []
  },

  "supraventricular-tachycardia": {
    score: 0,
    reasons: []
  },

  "lung-cancer": {
    score: 0,
    reasons: []
  },

  "tuberculosis": {
    score: 0,
    reasons: []
  }
};

export default ddx;