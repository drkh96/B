// ===============================
// Chest Pain Clinical Reasoning
// ===============================

function reasoning(ddx) {
  return Object.entries(ddx)
    .filter(([_, data]) => data.score !== 0)
    .sort((a, b) => b[1].score - a[1].score)
    .map(([diagnosisId, data]) => ({
      diagnosisId,
      score: data.score,
      reasons: data.reasons
    }));
}

export default reasoning;