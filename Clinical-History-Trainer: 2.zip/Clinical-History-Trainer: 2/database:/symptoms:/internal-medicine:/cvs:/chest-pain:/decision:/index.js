// ===============================
// Decision Engine
// ===============================

import logic from "./logic.js";
import reasoning from "./reasoning.js";

const decision = {
    logic,
    reasoning
};

export default decision;