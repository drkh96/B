// ===============================
// Chest Pain Decision Logic
// ===============================

const logic = {
  thresholds: {
    high: 60,
    moderate: 40,
    low: 20
  },

  nextSections: [
    {
      id: "acs-pathway",
      when: [
        "acute-coronary-syndrome",
        "myocardial-infarction",
        "unstable-angina",
        "stable-angina",
        "heart-failure"
      ],
      minScore: 40,
      show: [
        "systemic-review.cardiovascular",
        "systemic-review.risk-factors",
        "past-medical-history.cardiovascular",
        "drug-history.cardiac-drugs",
        "drug-history.anticoagulants",
        "family-history",
        "social-history"
      ]
    },

    {
      id: "pe-pathway",
      when: ["pulmonary-embolism"],
      minScore: 35,
      show: [
        "systemic-review.respiratory",
        "past-medical-history.thromboembolism",
        "drug-history.anticoagulants",
        "past-surgical-history",
        "social-history"
      ]
    },

    {
      id: "infection-pathway",
      when: [
        "pneumonia",
        "pleurisy",
        "tuberculosis",
        "lung-cancer"
      ],
      minScore: 35,
      show: [
        "systemic-review.general",
        "systemic-review.respiratory",
        "past-medical-history.respiratory",
        "drug-history.respiratory-drugs",
        "social-history"
      ]
    },

    {
      id: "gord-pathway",
      when: ["gord"],
      minScore: 35,
      show: [
        "systemic-review.gastrointestinal",
        "past-medical-history.gastrointestinal",
        "drug-history.gastric-drugs",
        "social-history"
      ]
    },

    {
      id: "musculoskeletal-pathway",
      when: [
        "costochondritis",
        "muscle-injury",
        "muscle-spasm",
        "rib-fracture",
        "herpes-zoster",
        "pneumothorax"
      ],
      minScore: 35,
      show: [
        "past-surgical-history",
        "social-history"
      ]
    }
  ]
};

export default logic;