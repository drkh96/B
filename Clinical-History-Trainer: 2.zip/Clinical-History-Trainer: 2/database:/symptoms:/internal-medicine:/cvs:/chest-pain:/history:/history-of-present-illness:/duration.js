import { SCORE } from "../../../../../../engine/scoring.js";

const duration = {
  id: "duration",

  title: {
    ar: "مدة الألم",
    en: "Duration"
  },

  question: {
    ar: "الألم شكد يبقى؟",
    en: "How long does the pain last?"
  },

  answers: [
    {
      id: "seconds",
      ar: "ثواني",
      en: "Seconds",
      effects: [
        {
          diagnosisId: "costochondritis",
          score: SCORE.MODERATE,
          reason: {
            ar: "الألم لثواني غالباً ليس قلبياً.",
            en: "Pain lasting seconds is usually non-cardiac."
          }
        },
        {
          diagnosisId: "muscle-injury",
          score: SCORE.MODERATE,
          reason: {
            ar: "يدعم السبب العضلي.",
            en: "Supports musculoskeletal pain."
          }
        },
        {
          diagnosisId: "acute-coronary-syndrome",
          score: SCORE.NEGATIVE,
          reason: {
            ar: "لا يدعم ACS.",
            en: "Against ACS."
          }
        }
      ]
    },

    {
      id: "5-15-min",
      ar: "5-15 دقيقة",
      en: "5-15 minutes",
      effects: [
        {
          diagnosisId: "stable-angina",
          score: SCORE.STRONG,
          reason: {
            ar: "مدة نموذجية للذبحة الصدرية.",
            en: "Typical duration of stable angina."
          }
        }
      ]
    },

    {
      id: "20-30-min",
      ar: "20-30 دقيقة",
      en: "20-30 minutes",
      effects: [
        {
          diagnosisId: "acute-coronary-syndrome",
          score: SCORE.STRONG,
          reason: {
            ar: "يدعم ACS.",
            en: "Supports ACS."
          }
        },
        {
          diagnosisId: "myocardial-infarction",
          score: SCORE.STRONG,
          reason: {
            ar: "يدعم MI.",
            en: "Supports MI."
          }
        }
      ]
    },

    {
      id: "hours",
      ar: "ساعات",
      en: "Hours",
      effects: [
        {
          diagnosisId: "pericarditis",
          score: SCORE.MODERATE,
          reason: {
            ar: "قد يستمر لساعات.",
            en: "May last for hours."
          }
        },
        {
          diagnosisId: "gord",
          score: SCORE.MODERATE,
          reason: {
            ar: "قد يستمر لساعات.",
            en: "May last for hours."
          }
        }
      ]
    },

    {
      id: "days",
      ar: "أيام",
      en: "Days",
      effects: [
        {
          diagnosisId: "costochondritis",
          score: SCORE.MODERATE,
          reason: {
            ar: "يدعم ألم جدار الصدر.",
            en: "Supports chest wall pain."
          }
        },
        {
          diagnosisId: "pericarditis",
          score: SCORE.WEAK,
          reason: {
            ar: "قد يستمر لأيام.",
            en: "May last for days."
          }
        }
      ]
    }
  ]
};

export default duration;