import cardiovascular from "./cardiovascular.js";
import respiratory from "./respiratory.js";
import gastrointestinal from "./gastrointestinal.js";
import thromboembolism from "./thromboembolism.js";

const pastMedicalHistory = {
    cardiovascular,
    respiratory,
    gastrointestinal,
    thromboembolism
};

export default
pastMedicalHistory;