import site from "./site.js";
import character from "./character.js";
import radiation from "./radiation.js";
import onset from "./onset.js";
import aggravating from "./aggravating.js";
import relieving from "./relieving.js";
import associatedSymptoms from "./associated-symptoms.js";
import duration from "./duration.js";
import course from "./course.js";
import severity from "./severity.js";

const analysis = [
  site,
  character,
  radiation,
  onset,
  aggravating,
  relieving,
  associatedSymptoms,
  duration,
  course,
  severity
];

export default analysis;