import { SCORE } from "../../../../../../engine/scoring.js";

const cardiovascular = {
  id: "cardiovascular",

  title: {
    ar: "التاريخ المرضي القلبي",
    en: "Past Cardiovascular History"
  },

  questions: [
    {
      id: "previous-mi",
      question: {
        ar: "صار عندك جلطة قلبية قبل؟",
        en: "Previous myocardial infarction?"
      },
      answers: [
        {
          id: "yes",
          ar: "نعم",
          en: "Yes",
          effects: [
            {
              diagnosisId: "myocardial-infarction",
              score: SCORE.VERY_STRONG,
              reason: {
                ar: "MI سابق يزيد احتمال تكرر الاحتشاء.",
                en: "Previous MI strongly increases the risk of recurrent MI."
              }
            },
            {
              diagnosisId: "acute-coronary-syndrome",
              score: SCORE.STRONG,
              reason: {
                ar: "وجود MI سابق يدعم ACS.",
                en: "Previous MI supports ACS."
              }
            }
          ]
        },
        {
          id: "no",
          ar: "لا",
          en: "No",
          effects: []
        }
      ]
    },

    {
      id: "previous-angina",
      question: {
        ar: "عندك ذبحة صدرية من قبل؟",
        en: "Previous angina?"
      },
      answers: [
        {
          id: "yes",
          ar: "نعم",
          en: "Yes",
          effects: [
            {
              diagnosisId: "stable-angina",
              score: SCORE.VERY_STRONG,
              reason: {
                ar: "وجود ذبحة سابقة يدعم Stable Angina.",
                en: "Previous angina strongly supports stable angina."
              }
            },
            {
              diagnosisId: "unstable-angina",
              score: SCORE.MODERATE,
              reason: {
                ar: "قد تتطور الذبحة المستقرة إلى غير مستقرة.",
                en: "Stable angina may progress to unstable angina."
              }
            },
            {
              diagnosisId: "acute-coronary-syndrome",
              score: SCORE.MODERATE,
              reason: {
                ar: "وجود ذبحة سابقة يزيد احتمال ACS.",
                en: "Previous angina increases the likelihood of ACS."
              }
            }
          ]
        },
        {
          id: "no",
          ar: "لا",
          en: "No",
          effects: []
        }
      ]
    },

    {
      id: "pci-cabg",
      question: {
        ar: "سويت قسطرة أو شبكات أو تبديل شرايين؟",
        en: "Previous PCI or CABG?"
      },
      answers: [
        {
          id: "yes",
          ar: "نعم",
          en: "Yes",
          effects: [
            {
              diagnosisId: "acute-coronary-syndrome",
              score: SCORE.STRONG,
              reason: {
                ar: "وجود PCI/CABG يدل على مرض شرايين تاجية.",
                en: "Previous PCI/CABG indicates coronary artery disease."
              }
            },
            {
              diagnosisId: "stable-angina",
              score: SCORE.MODERATE,
              reason: {
                ar: "يدعم وجود CAD مزمن.",
                en: "Supports chronic coronary artery disease."
              }
            }
          ]
        },
        {
          id: "no",
          ar: "لا",
          en: "No",
          effects: []
        }
      ]
    },

    {
      id: "heart-failure",
      question: {
        ar: "كالولك عندك ضعف بعضلة القلب أو فشل قلب؟",
        en: "History of heart failure?"
      },
      answers: [
        {
          id: "yes",
          ar: "نعم",
          en: "Yes",
          effects: [
            {
              diagnosisId: "heart-failure",
              score: SCORE.VERY_STRONG,
              reason: {
                ar: "التاريخ السابق يدعم Heart Failure.",
                en: "Previous history strongly supports heart failure."
              }
            }
          ]
        },
        {
          id: "no",
          ar: "لا",
          en: "No",
          effects: []
        }
      ]
    },

    {
      id: "valvular-disease",
      question: {
        ar: "عندك مرض بصمامات القلب؟",
        en: "History of valvular heart disease?"
      },
      answers: [
        {
          id: "yes",
          ar: "نعم",
          en: "Yes",
          effects: [
            {
              diagnosisId: "mitral-valve-prolapse",
              score: SCORE.VERY_STRONG,
              reason: {
                ar: "التاريخ السابق يدعم MVP.",
                en: "Previous valvular disease supports MVP."
              }
            },
            {
              diagnosisId: "heart-failure",
              score: SCORE.MODERATE,
              reason: {
                ar: "أمراض الصمامات قد تؤدي إلى Heart Failure.",
                en: "Valvular disease may lead to heart failure."
              }
            }
          ]
        },
        {
          id: "no",
          ar: "لا",
          en: "No",
          effects: []
        }
      ]
    },

    {
      id: "hyperlipidemia",
      question: {
        ar: "عندك ارتفاع بالكولسترول أو الدهون؟",
        en: "Hyperlipidemia?"
      },
      answers: [
        {
          id: "yes",
          ar: "نعم",
          en: "Yes",
          effects: [
            {
              diagnosisId: "acute-coronary-syndrome",
              score: SCORE.MODERATE,
              reason: {
                ar: "ارتفاع الدهون من عوامل خطورة ACS.",
                en: "Hyperlipidemia is a major risk factor for ACS."
              }
            },
            {
              diagnosisId: "stable-angina",
              score: SCORE.MODERATE,
              reason: {
                ar: "يدعم مرض الشرايين التاجية.",
                en: "Supports coronary artery disease."
              }
            }
          ]
        },
        {
          id: "no",
          ar: "لا",
          en: "No",
          effects: []
        }
      ]
    }
  ]
};

export default cardiovascular;