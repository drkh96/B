import { SCORE } from "../../../../../../engine/scoring.js";

const onset = {
  id: "onset",

  title: {
    ar: "بداية الألم",
    en: "Onset"
  },

  question: {
    ar: "شلون بدأ الألم؟",
    en: "How did the pain start?"
  },

  answers: [
    {
      id: "sudden",
      ar: "فجأة",
      en: "Sudden",
      effects: [
        {
          diagnosisId: "myocardial-infarction",
          score: SCORE.STRONG,
          reason: {
            ar: "البداية المفاجئة تدعم MI.",
            en: "Sudden onset supports MI."
          }
        },
        {
          diagnosisId: "aortic-dissection",
          score: SCORE.VERY_STRONG,
          reason: {
            ar: "البداية المفاجئة الشديدة من العلامات الكلاسيكية لـ Aortic Dissection.",
            en: "Classic feature of aortic dissection."
          }
        },
        {
          diagnosisId: "pulmonary-embolism",
          score: SCORE.STRONG,
          reason: {
            ar: "قد يبدأ PE بشكل مفاجئ.",
            en: "PE often has sudden onset."
          }
        },
        {
          diagnosisId: "pneumothorax",
          score: SCORE.VERY_STRONG,
          reason: {
            ar: "البداية المفاجئة تدعم Pneumothorax.",
            en: "Sudden onset supports pneumothorax."
          }
        }
      ]
    },

    {
      id: "gradual",
      ar: "بالتدريج",
      en: "Gradual",
      effects: [
        {
          diagnosisId: "stable-angina",
          score: SCORE.MODERATE,
          reason: {
            ar: "قد يكون تدريجياً مع الجهد.",
            en: "May develop gradually with exertion."
          }
        },
        {
          diagnosisId: "gord",
          score: SCORE.MODERATE,
          reason: {
            ar: "غالباً يبدأ تدريجياً.",
            en: "Usually gradual."
          }
        },
        {
          diagnosisId: "pneumonia",
          score: SCORE.MODERATE,
          reason: {
            ar: "غالباً يتطور تدريجياً.",
            en: "Usually develops gradually."
          }
        },
        {
          diagnosisId: "pericarditis",
          score: SCORE.WEAK,
          reason: {
            ar: "قد يتطور خلال ساعات.",
            en: "May develop over hours."
          }
        }
      ]
    }
  ]
};

export default onset;