import { SCORE } from "../../../../../../engine/scoring.js";

const aggravating = {
  id: "aggravating",

  title: {
    ar: "العوامل التي تزيد الألم",
    en: "Aggravating Factors"
  },

  question: {
    ar: "شنو الأشياء اللي تزيد الألم؟",
    en: "What makes the pain worse?"
  },

  answers: [
    {
      id: "exertion",
      ar: "الجهد / المشي / صعود الدرج",
      en: "Exertion",
      effects: [
        {
          diagnosisId: "stable-angina",
          score: SCORE.VERY_STRONG,
          reason: {
            ar: "يزيد مع الجهد في Stable Angina.",
            en: "Typical of stable angina."
          }
        },
        {
          diagnosisId: "acute-coronary-syndrome",
          score: SCORE.MODERATE,
          reason: {
            ar: "قد يزداد مع الجهد.",
            en: "May worsen with exertion."
          }
        }
      ]
    },

    {
      id: "deep-breath",
      ar: "النفس العميق",
      en: "Deep inspiration",
      effects: [
        {
          diagnosisId: "pleurisy",
          score: SCORE.VERY_STRONG,
          reason: {
            ar: "ألم جنبي يزداد مع الشهيق.",
            en: "Typical pleuritic pain."
          }
        },
        {
          diagnosisId: "pulmonary-embolism",
          score: SCORE.STRONG,
          reason: {
            ar: "قد يزداد مع الشهيق.",
            en: "May worsen with inspiration."
          }
        },
        {
          diagnosisId: "pericarditis",
          score: SCORE.MODERATE,
          reason: {
            ar: "قد يزداد مع التنفس.",
            en: "May worsen with inspiration."
          }
        }
      ]
    },

    {
      id: "cough",
      ar: "الكحة",
      en: "Cough",
      effects: [
        {
          diagnosisId: "pneumonia",
          score: SCORE.STRONG,
          reason: {
            ar: "يدعم Pneumonia.",
            en: "Supports pneumonia."
          }
        },
        {
          diagnosisId: "pleurisy",
          score: SCORE.STRONG,
          reason: {
            ar: "يدعم التهاب البلورا.",
            en: "Supports pleurisy."
          }
        }
      ]
    },

    {
      id: "movement",
      ar: "الحركة أو الضغط على المكان",
      en: "Movement / palpation",
      effects: [
        {
          diagnosisId: "costochondritis",
          score: SCORE.VERY_STRONG,
          reason: {
            ar: "يدعم ألم جدار الصدر.",
            en: "Supports chest wall pain."
          }
        },
        {
          diagnosisId: "muscle-injury",
          score: SCORE.STRONG,
          reason: {
            ar: "يدعم إصابة عضلية.",
            en: "Supports muscle injury."
          }
        }
      ]
    },

    {
      id: "meal",
      ar: "بعد الأكل",
      en: "After meals",
      effects: [
        {
          diagnosisId: "gord",
          score: SCORE.VERY_STRONG,
          reason: {
            ar: "يدعم GORD.",
            en: "Supports GORD."
          }
        }
      ]
    },

    {
      id: "lying-flat",
      ar: "الاستلقاء",
      en: "Lying flat",
      effects: [
        {
          diagnosisId: "pericarditis",
          score: SCORE.STRONG,
          reason: {
            ar: "يزداد بالاستلقاء.",
            en: "Pain worsens when lying flat."
          }
        },
        {
          diagnosisId: "gord",
          score: SCORE.MODERATE,
          reason: {
            ar: "قد يزداد عند الاستلقاء.",
            en: "May worsen when lying flat."
          }
        }
      ]
    }
  ]
};

export default aggravating;