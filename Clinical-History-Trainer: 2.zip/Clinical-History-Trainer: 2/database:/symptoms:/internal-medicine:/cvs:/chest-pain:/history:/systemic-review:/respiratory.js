import { SCORE } from "../../../../../../engine/scoring.js";

const respiratory = {
  id: "respiratory",

  title: {
    ar: "مراجعة الجهاز التنفسي",
    en: "Respiratory Review"
  },

  questions: [
    {
      id: "cough",
      question: {
        ar: "عندك كحة؟",
        en: "Do you have cough?"
      },
      answers: [
        {
          id: "yes",
          ar: "نعم",
          en: "Yes",
          effects: [
            {
              diagnosisId: "pneumonia",
              score: SCORE.STRONG,
              reason: {
                ar: "الكحة تدعم Pneumonia.",
                en: "Cough supports pneumonia."
              }
            },
            {
              diagnosisId: "pleurisy",
              score: SCORE.MODERATE,
              reason: {
                ar: "الكحة قد ترافق Pleurisy.",
                en: "Cough may occur with pleurisy."
              }
            }
          ]
        },
        {
          id: "no",
          ar: "لا",
          en: "No",
          effects: []
        }
      ]
    },

    {
      id: "sputum",
      question: {
        ar: "الكحة وياها بلغم؟",
        en: "Is there sputum?"
      },
      answers: [
        {
          id: "yes",
          ar: "نعم",
          en: "Yes",
          effects: [
            {
              diagnosisId: "pneumonia",
              score: SCORE.STRONG,
              reason: {
                ar: "البلغم يدعم عدوى صدرية مثل Pneumonia.",
                en: "Sputum supports chest infection such as pneumonia."
              }
            }
          ]
        },
        {
          id: "no",
          ar: "لا",
          en: "No",
          effects: []
        }
      ]
    },

    {
      id: "hemoptysis",
      question: {
        ar: "طلع ويا الكحة دم؟",
        en: "Have you coughed blood?"
      },
      answers: [
        {
          id: "yes",
          ar: "نعم",
          en: "Yes",
          effects: [
            {
              diagnosisId: "pulmonary-embolism",
              score: SCORE.STRONG,
              reason: {
                ar: "نفث الدم قد يحدث في PE.",
                en: "Hemoptysis may occur in PE."
              }
            },
            {
              diagnosisId: "pneumonia",
              score: SCORE.MODERATE,
              reason: {
                ar: "قد يحدث نفث دم مع Pneumonia.",
                en: "Hemoptysis may occur with pneumonia."
              }
            },
            {
              diagnosisId: "lung-cancer",
              score: SCORE.MODERATE,
              reason: {
                ar: "نفث الدم قد يدعم Lung Cancer خصوصاً مع نزول وزن أو تدخين.",
                en: "Hemoptysis may support lung cancer, especially with weight loss or smoking."
              }
            }
          ]
        },
        {
          id: "no",
          ar: "لا",
          en: "No",
          effects: []
        }
      ]
    },

    {
      id: "wheeze",
      question: {
        ar: "يصير عندك صفير بالصدر؟",
        en: "Do you have wheeze?"
      },
      answers: [
        {
          id: "yes",
          ar: "نعم",
          en: "Yes",
          effects: [
            {
              diagnosisId: "heart-failure",
              score: SCORE.MODERATE,
              reason: {
                ar: "الصفير قد يحدث مع احتقان الرئة بسبب Heart Failure.",
                en: "Wheeze may occur with pulmonary congestion due to heart failure."
              }
            }
          ]
        },
        {
          id: "no",
          ar: "لا",
          en: "No",
          effects: []
        }
      ]
    },

    {
      id: "pleuritic-pain",
      question: {
        ar: "الألم يزيد من تاخذ نفس عميق؟",
        en: "Does the pain worsen with deep breathing?"
      },
      answers: [
        {
          id: "yes",
          ar: "نعم",
          en: "Yes",
          effects: [
            {
              diagnosisId: "pleurisy",
              score: SCORE.VERY_STRONG,
              reason: {
                ar: "الألم الذي يزيد مع النفس يدعم Pleurisy.",
                en: "Pain worsened by breathing supports pleurisy."
              }
            },
            {
              diagnosisId: "pulmonary-embolism",
              score: SCORE.STRONG,
              reason: {
                ar: "الألم الجنبي قد يحدث في PE.",
                en: "Pleuritic pain may occur in PE."
              }
            },
            {
              diagnosisId: "pneumothorax",
              score: SCORE.STRONG,
              reason: {
                ar: "الألم الجنبي المفاجئ قد يحدث في Pneumothorax.",
                en: "Sudden pleuritic pain may occur in pneumothorax."
              }
            }
          ]
        },
        {
          id: "no",
          ar: "لا",
          en: "No",
          effects: []
        }
      ]
    }
  ]
};

export default respiratory;