import { SCORE } from "../../../../../../engine/scoring.js";

const cardiovascular = {
  id: "cardiovascular",

  title: {
    ar: "مراجعة الجهاز القلبي",
    en: "Cardiovascular Review"
  },

  questions: [
    {
      id: "palpitations",
      question: {
        ar: "عندك خفقان بالقلب؟",
        en: "Do you have palpitations?"
      },
      answers: [
        {
          id: "yes",
          ar: "نعم",
          en: "Yes",
          effects: [
            {
              diagnosisId: "atrial-fibrillation",
              score: SCORE.STRONG,
              reason: {
                ar: "الخفقان يدعم اضطراب النظم مثل AF.",
                en: "Palpitations support arrhythmia such as AF."
              }
            },
            {
              diagnosisId: "mitral-valve-prolapse",
              score: SCORE.MODERATE,
              reason: {
                ar: "قد يحدث خفقان مع Mitral Valve Prolapse.",
                en: "Palpitations may occur with mitral valve prolapse."
              }
            }
          ]
        },
        {
          id: "no",
          ar: "لا",
          en: "No",
          effects: []
        }
      ]
    },

    {
      id: "orthopnea",
      question: {
        ar: "تحتاج أكثر من مخدة حتى تنام؟",
        en: "Do you need extra pillows to sleep?"
      },
      answers: [
        {
          id: "yes",
          ar: "نعم",
          en: "Yes",
          effects: [
            {
              diagnosisId: "heart-failure",
              score: SCORE.VERY_STRONG,
              reason: {
                ar: "Orthopnea علامة مهمة لفشل القلب.",
                en: "Orthopnea strongly supports heart failure."
              }
            }
          ]
        },
        {
          id: "no",
          ar: "لا",
          en: "No",
          effects: []
        }
      ]
    },

    {
      id: "pnd",
      question: {
        ar: "تصحى بالليل مختنگ وتحتاج تكعد حتى تتحسن؟",
        en: "Do you wake up at night short of breath and need to sit up?"
      },
      answers: [
        {
          id: "yes",
          ar: "نعم",
          en: "Yes",
          effects: [
            {
              diagnosisId: "heart-failure",
              score: SCORE.VERY_STRONG,
              reason: {
                ar: "PND علامة قوية لفشل القلب.",
                en: "PND strongly supports heart failure."
              }
            }
          ]
        },
        {
          id: "no",
          ar: "لا",
          en: "No",
          effects: []
        }
      ]
    },

    {
      id: "leg-swelling",
      question: {
        ar: "عندك تورم بالرجلين؟",
        en: "Do you have leg swelling?"
      },
      answers: [
        {
          id: "yes",
          ar: "نعم",
          en: "Yes",
          effects: [
            {
              diagnosisId: "heart-failure",
              score: SCORE.STRONG,
              reason: {
                ar: "تورم الرجلين يدعم فشل القلب.",
                en: "Leg swelling supports heart failure."
              }
            },
            {
              diagnosisId: "pulmonary-embolism",
              score: SCORE.MODERATE,
              reason: {
                ar: "تورم رجل واحدة قد يدعم DVT وبالتالي PE.",
                en: "Unilateral leg swelling may suggest DVT and PE."
              }
            }
          ]
        },
        {
          id: "no",
          ar: "لا",
          en: "No",
          effects: []
        }
      ]
    },

    {
      id: "claudication",
      question: {
        ar: "يصير عندك ألم بالساق من تمشي ويخف من ترتاح؟",
        en: "Do you get calf pain on walking that improves with rest?"
      },
      answers: [
        {
          id: "yes",
          ar: "نعم",
          en: "Yes",
          effects: [
            {
              diagnosisId: "acute-coronary-syndrome",
              score: SCORE.MODERATE,
              reason: {
                ar: "Claudication يدل على atherosclerosis ويدعم IHD.",
                en: "Claudication suggests atherosclerosis and supports IHD."
              }
            },
            {
              diagnosisId: "stable-angina",
              score: SCORE.MODERATE,
              reason: {
                ar: "Claudication يشارك Stable Angina بنفس عامل الخطورة: atherosclerosis.",
                en: "Claudication and stable angina share atherosclerosis."
              }
            }
          ]
        },
        {
          id: "no",
          ar: "لا",
          en: "No",
          effects: []
        }
      ]
    }
  ]
};

export default cardiovascular;