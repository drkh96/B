import { SCORE } from "../../../../../../engine/scoring.js";

const gastrointestinal = {
  id: "gastrointestinal",

  title: {
    ar: "التاريخ المرضي الهضمي",
    en: "Past Gastrointestinal History"
  },

  questions: [
    {
      id: "gord-history",
      question: {
        ar: "عندك ارتجاع أو حموضة مزمنة؟",
        en: "History of reflux or chronic heartburn?"
      },
      answers: [
        {
          id: "yes",
          ar: "نعم",
          en: "Yes",
          effects: [
            {
              diagnosisId: "gord",
              score: SCORE.VERY_STRONG,
              reason: {
                ar: "وجود ارتجاع مزمن سابق يدعم GORD.",
                en: "Previous chronic reflux strongly supports GORD."
              }
            }
          ]
        },
        {
          id: "no",
          ar: "لا",
          en: "No",
          effects: []
        }
      ]
    },

    {
      id: "peptic-ulcer",
      question: {
        ar: "عندك قرحة معدة أو اثني عشري قبل؟",
        en: "Previous peptic ulcer disease?"
      },
      answers: [
        {
          id: "yes",
          ar: "نعم",
          en: "Yes",
          effects: [
            {
              diagnosisId: "gord",
              score: SCORE.MODERATE,
              reason: {
                ar: "تاريخ القرحة أو مشاكل المعدة قد يدعم سبب هضمي للألم.",
                en: "Previous ulcer or gastric disease may support a gastrointestinal cause of pain."
              }
            }
          ]
        },
        {
          id: "no",
          ar: "لا",
          en: "No",
          effects: []
        }
      ]
    },

    {
      id: "gallbladder-disease",
      question: {
        ar: "عندك حصى مرارة أو مشاكل بالمرارة؟",
        en: "History of gallstones or gallbladder disease?"
      },
      answers: [
        {
          id: "yes",
          ar: "نعم",
          en: "Yes",
          effects: [
            {
              diagnosisId: "gord",
              score: SCORE.WEAK,
              reason: {
                ar: "مشاكل الجهاز الهضمي العلوي قد تتشابه مع ألم الصدر.",
                en: "Upper GI problems can mimic chest pain."
              }
            }
          ]
        },
        {
          id: "no",
          ar: "لا",
          en: "No",
          effects: []
        }
      ]
    }
  ]
};

export default gastrointestinal;