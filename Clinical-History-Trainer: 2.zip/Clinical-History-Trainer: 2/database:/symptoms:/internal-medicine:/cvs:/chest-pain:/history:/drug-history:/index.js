import currentMedications from "./current-medications.js";
import anticoagulants from "./anticoagulants.js";
import antiplatelets from "./antiplatelets.js";
import allergies from "./allergies.js";
import insulin from "./insulin.js";
import steroids from "./steroids.js";

const drugHistory = {
  currentMedications,
  anticoagulants,
  antiplatelets,
  allergies,
  insulin,
  steroids
};

export default drugHistory;