import { SCORE } from "../../../../../engine/scoring.js";

const familyHistory = {
  id: "family-history",

  title: {
    ar: "التاريخ العائلي",
    en: "Family History"
  },

  questions: [
    {
      id: "family-ihd",
      question: {
        ar: "أكو أحد من أهلك عنده جلطة أو ذبحة أو مرض شرايين؟",
        en: "Any family history of MI, angina, or coronary artery disease?"
      },
      answers: [
        {
          id: "yes",
          ar: "نعم",
          en: "Yes",
          effects: [
            {
              diagnosisId: "acute-coronary-syndrome",
              score: SCORE.STRONG,
              reason: {
                ar: "التاريخ العائلي لمرض الشرايين يزيد احتمال ACS.",
                en: "Family history of CAD increases ACS risk."
              }
            },
            {
              diagnosisId: "myocardial-infarction",
              score: SCORE.STRONG,
              reason: {
                ar: "التاريخ العائلي يزيد خطر MI.",
                en: "Family history increases MI risk."
              }
            },
            {
              diagnosisId: "stable-angina",
              score: SCORE.MODERATE,
              reason: {
                ar: "يدعم وجود قابلية عائلية لمرض الشرايين.",
                en: "Supports familial risk of coronary artery disease."
              }
            }
          ]
        },
        {
          id: "no",
          ar: "لا",
          en: "No",
          effects: []
        }
      ]
    },

    {
      id: "sudden-death",
      question: {
        ar: "أكو وفاة مفاجئة بالعائلة؟",
        en: "Any sudden death in the family?"
      },
      answers: [
        {
          id: "yes",
          ar: "نعم",
          en: "Yes",
          effects: [
            {
              diagnosisId: "myocardial-infarction",
              score: SCORE.MODERATE,
              reason: {
                ar: "الوفاة المفاجئة قد تشير إلى مرض قلبي عائلي أو IHD.",
                en: "Sudden death may suggest familial cardiac disease or IHD."
              }
            },
            {
              diagnosisId: "acute-coronary-syndrome",
              score: SCORE.MODERATE,
              reason: {
                ar: "تدعم وجود خطورة قلبية عائلية.",
                en: "Supports familial cardiac risk."
              }
            }
          ]
        },
        {
          id: "no",
          ar: "لا",
          en: "No",
          effects: []
        }
      ]
    },

    {
      id: "family-thrombosis",
      question: {
        ar: "أكو أحد بالعائلة عنده جلطات متكررة بالساق أو الرئة؟",
        en: "Any family history of recurrent DVT or PE?"
      },
      answers: [
        {
          id: "yes",
          ar: "نعم",
          en: "Yes",
          effects: [
            {
              diagnosisId: "pulmonary-embolism",
              score: SCORE.STRONG,
              reason: {
                ar: "التاريخ العائلي للجلطات يدعم قابلية تخثر وقد يدعم PE.",
                en: "Family history of thrombosis suggests thrombophilia and supports PE."
              }
            }
          ]
        },
        {
          id: "no",
          ar: "لا",
          en: "No",
          effects: []
        }
      ]
    }
  ]
};

export default familyHistory;