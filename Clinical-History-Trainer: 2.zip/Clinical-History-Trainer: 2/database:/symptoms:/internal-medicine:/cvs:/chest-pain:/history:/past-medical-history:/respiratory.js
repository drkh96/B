import { SCORE } from "../../../../../../engine/scoring.js";

const respiratory = {
  id: "respiratory",

  title: {
    ar: "التاريخ المرضي التنفسي",
    en: "Past Respiratory History"
  },

  questions: [
    {
      id: "previous-pneumonia",
      question: {
        ar: "صار عندك التهاب رئة قبل؟",
        en: "Previous pneumonia?"
      },
      answers: [
        {
          id: "yes",
          ar: "نعم",
          en: "Yes",
          effects: [
            {
              diagnosisId: "pneumonia",
              score: SCORE.MODERATE,
              reason: {
                ar: "التهاب الرئة السابق قد يدعم تكرر أو استمرار المشكلة التنفسية.",
                en: "Previous pneumonia may support recurrent or ongoing respiratory disease."
              }
            }
          ]
        },
        {
          id: "no",
          ar: "لا",
          en: "No",
          effects: []
        }
      ]
    },

    {
      id: "copd-asthma",
      question: {
        ar: "عندك ربو أو COPD؟",
        en: "Asthma or COPD?"
      },
      answers: [
        {
          id: "yes",
          ar: "نعم",
          en: "Yes",
          effects: [
            {
              diagnosisId: "pneumonia",
              score: SCORE.WEAK,
              reason: {
                ar: "الأمراض التنفسية المزمنة قد تزيد احتمال العدوى الصدرية.",
                en: "Chronic respiratory disease may increase risk of chest infection."
              }
            },
            {
              diagnosisId: "pneumothorax",
              score: SCORE.MODERATE,
              reason: {
                ar: "COPD قد يزيد خطر pneumothorax.",
                en: "COPD may increase risk of pneumothorax."
              }
            }
          ]
        },
        {
          id: "no",
          ar: "لا",
          en: "No",
          effects: []
        }
      ]
    },

    {
      id: "tb-history",
      question: {
        ar: "صار عندك تدرن/سل قبل؟",
        en: "Previous tuberculosis?"
      },
      answers: [
        {
          id: "yes",
          ar: "نعم",
          en: "Yes",
          effects: [
            {
              diagnosisId: "tuberculosis",
              score: SCORE.VERY_STRONG,
              reason: {
                ar: "تاريخ سابق للسل يدعم TB.",
                en: "Previous TB strongly supports tuberculosis."
              }
            }
          ]
        },
        {
          id: "no",
          ar: "لا",
          en: "No",
          effects: []
        }
      ]
    }
  ]
};

export default respiratory;