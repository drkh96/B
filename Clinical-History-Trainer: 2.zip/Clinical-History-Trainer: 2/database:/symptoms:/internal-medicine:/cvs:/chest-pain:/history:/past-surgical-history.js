import { SCORE } from "../../../../../engine/scoring.js";

const pastSurgicalHistory = {
  id: "past-surgical-history",

  title: {
    ar: "التاريخ الجراحي السابق",
    en: "Past Surgical History"
  },

  questions: [
    {
      id: "cardiac-surgery",
      question: {
        ar: "سويت عملية قلب مفتوح أو تبديل شرايين قبل؟",
        en: "Previous open heart surgery or CABG?"
      },
      answers: [
        {
          id: "yes",
          ar: "نعم",
          en: "Yes",
          effects: [
            {
              diagnosisId: "acute-coronary-syndrome",
              score: SCORE.STRONG,
              reason: {
                ar: "CABG سابق يدل على مرض شرايين تاجية.",
                en: "Previous CABG indicates coronary artery disease."
              }
            },
            {
              diagnosisId: "stable-angina",
              score: SCORE.MODERATE,
              reason: {
                ar: "يدعم وجود مرض شرايين مزمن.",
                en: "Supports chronic coronary artery disease."
              }
            }
          ]
        },
        {
          id: "no",
          ar: "لا",
          en: "No",
          effects: []
        }
      ]
    },

    {
      id: "recent-surgery",
      question: {
        ar: "سويت عملية خلال آخر شهر؟",
        en: "Any surgery in the last month?"
      },
      answers: [
        {
          id: "yes",
          ar: "نعم",
          en: "Yes",
          effects: [
            {
              diagnosisId: "pulmonary-embolism",
              score: SCORE.VERY_STRONG,
              reason: {
                ar: "العمليات الحديثة تزيد خطر DVT/PE.",
                en: "Recent surgery increases DVT/PE risk."
              }
            }
          ]
        },
        {
          id: "no",
          ar: "لا",
          en: "No",
          effects: []
        }
      ]
    },

    {
      id: "trauma",
      question: {
        ar: "صار عندك ضربة أو إصابة بالصدر؟",
        en: "Any recent chest trauma?"
      },
      answers: [
        {
          id: "yes",
          ar: "نعم",
          en: "Yes",
          effects: [
            {
              diagnosisId: "rib-fracture",
              score: SCORE.VERY_STRONG,
              reason: {
                ar: "إصابة الصدر تدعم كسر الضلع.",
                en: "Chest trauma strongly supports rib fracture."
              }
            },
            {
              diagnosisId: "pneumothorax",
              score: SCORE.STRONG,
              reason: {
                ar: "إصابة الصدر قد تسبب pneumothorax.",
                en: "Chest trauma may cause pneumothorax."
              }
            },
            {
              diagnosisId: "muscle-injury",
              score: SCORE.STRONG,
              reason: {
                ar: "الإصابة قد تسبب ألم عضلي.",
                en: "Trauma may cause muscle injury."
              }
            }
          ]
        },
        {
          id: "no",
          ar: "لا",
          en: "No",
          effects: []
        }
      ]
    },

    {
      id: "immobilization",
      question: {
        ar: "بعد العملية أو الإصابة بقيت بالفراش فترة طويلة؟",
        en: "Were you immobilized after surgery or injury?"
      },
      answers: [
        {
          id: "yes",
          ar: "نعم",
          en: "Yes",
          effects: [
            {
              diagnosisId: "pulmonary-embolism",
              score: SCORE.STRONG,
              reason: {
                ar: "قلة الحركة بعد الجراحة أو الإصابة تزيد خطر PE.",
                en: "Immobilization after surgery or trauma increases PE risk."
              }
            }
          ]
        },
        {
          id: "no",
          ar: "لا",
          en: "No",
          effects: []
        }
      ]
    }
  ]
};

export default pastSurgicalHistory;