function management(patient = {}, state = {}) {
  const top = state.sortedDDx?.[0]?.id;

  const common = [
    "Assess ABCDE.",
    "Give oxygen only if hypoxic.",
    "Establish IV access.",
    "Monitor vital signs.",
    "Call senior/urgent help if unstable."
  ];

  const plans = {
    "acute-coronary-syndrome": [
      ...common,
      "Immediate ECG and troponin.",
      "Give aspirin if not contraindicated.",
      "Add P2Y12 inhibitor according to local protocol.",
      "Give GTN if BP allows.",
      "Give morphine if severe pain.",
      "Anticoagulation as per ACS protocol.",
      "Primary PCI if STEMI and available.",
      "Thrombolysis if STEMI and PCI unavailable.",
      "Start secondary prevention: statin, beta blocker, ACE inhibitor if appropriate."
    ],

    "myocardial-infarction": [
      ...common,
      "Treat as ACS emergency.",
      "Aspirin + P2Y12 inhibitor.",
      "Anticoagulation.",
      "Urgent reperfusion: primary PCI preferred.",
      "Thrombolysis if PCI unavailable and no contraindications.",
      "Admit to coronary care unit."
    ],

    "aortic-dissection": [
      ...common,
      "Urgent senior and vascular/cardiothoracic review.",
      "Control pain with IV opioid.",
      "Control BP and heart rate, usually IV beta blocker.",
      "Urgent CT angiography.",
      "Type A dissection: emergency surgery.",
      "Type B dissection: medical/endovascular depending on complications."
    ],

    "pulmonary-embolism": [
      ...common,
      "Assess PE severity and hemodynamic stability.",
      "Start anticoagulation if PE likely and no contraindication.",
      "CTPA to confirm diagnosis.",
      "Thrombolysis if massive PE with shock.",
      "Consider oxygen and supportive care.",
      "Investigate for DVT and risk factors."
    ],

    "pneumothorax": [
      ...common,
      "If tension pneumothorax: immediate needle decompression.",
      "Then insert chest drain.",
      "If small and stable: oxygen, observation, repeat imaging.",
      "If large or symptomatic: aspiration or chest drain depending on protocol."
    ],

    "pneumonia": [
      ...common,
      "Assess severity.",
      "Give antibiotics according to local guideline.",
      "Give fluids if dehydrated or septic.",
      "Oxygen if hypoxic.",
      "Antipyretic and analgesia.",
      "Admit if severe or unstable."
    ],

    "gord": [
      "Reassure after excluding cardiac red flags.",
      "Lifestyle advice: avoid fatty meals, late meals, caffeine, smoking.",
      "Start PPI trial.",
      "Consider endoscopy if alarm symptoms or persistent symptoms."
    ],

    "costochondritis": [
      "Reassure after excluding serious causes.",
      "Analgesia such as NSAID if not contraindicated.",
      "Local heat and rest.",
      "Safety-net: return if dyspnea, sweating, syncope, or worsening pain."
    ]
  };

  return {
    title: "Management",
    diagnosisId: top || null,
    items: plans[top] || common
  };
}

export default management;