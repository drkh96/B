// ===============================
// Clinical Report
// ===============================

import caseScenario from "./case-scenario.js";
import examination from "./examination.js";
import investigations from "./investigations.js";
import management from "./management.js";

const report = {
    caseScenario,
    examination,
    investigations,
    management
};

export default report;