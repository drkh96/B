// ===============================
// Chest Pain Module
// ===============================

import history from "./history/index.js";
import ddx from "./ddx.js";
import decision from "./decision/index.js";
import report from "./report/index.js";

const chestPain = {
    id: "chest-pain",

    name: {
        ar: "ألم الصدر",
        en: "Chest Pain"
    },

    history,
    ddx,
    decision,
    report
};

export default chestPain;