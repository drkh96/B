import symptomTemplate from "./symptom-template.js";
import diagnosisTemplate from "./diagnosis-template.js";

const templates = {
  symptomTemplate,
  diagnosisTemplate
};

export default templates;