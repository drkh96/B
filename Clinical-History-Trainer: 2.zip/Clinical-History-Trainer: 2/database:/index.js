import common from "./common/index.js";
import templates from "./templates/index.js";
import symptoms from "./symptoms/index.js";
import diagnoses from "./diagnoses/index.js";
import cases from "./cases/index.js";
import subjects from "./subjects/index.js";
import systems from "./systems/index.js";

const database = {
  common,
  templates,
  symptoms,
  diagnoses,
  cases,
  subjects,
  systems
};

export default database;