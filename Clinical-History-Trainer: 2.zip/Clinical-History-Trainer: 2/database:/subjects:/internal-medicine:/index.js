const internalMedicine = {
  id: "internal-medicine",

  name: {
    ar: "الباطنية",
    en: "Internal Medicine"
  },

  systems: {}
};

export default internalMedicine;