import internalMedicine from "./internal-medicine/index.js";

const subjects = {
  internalMedicine
};

export default subjects;